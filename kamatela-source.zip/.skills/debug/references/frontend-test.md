# Vitest Reproduction Guide

Vitest turns a user symptom into a repeatable failing command. Before the fix the exit code must be non-zero; after the fix the same command must be 0. See SKILL.md for sandbox path rules.

## Phase 1: Choose a testing approach

Description: pick the right runner based on the user-visible symptom.

1. Use node

   - Pure functions, computation, query transforms, and data formatting.
   - Fast; good for establishing a baseline first.

2. Use jsdom + RTL

   - DOM, conditional rendering, callbacks, state updates, and form interactions.
   - Does not support real CSS, layout, Canvas, or `getBoundingClientRect`.

3. Use browser mode

   - Layout, styles, drag-and-drop, Canvas, real event bubbling, and dimensions.
   - Uses real Chromium; the layout engine runs fully, so size, position, stacking, occlusion, and overflow can all be read as numeric values and asserted directly — this is the heaviest reproduction approach in this skill.

4. Escalation rule

   - Escalate step by step: node → jsdom → browser mode.
   - If the current runner passes green but the symptom does not appear, the bug cannot be reproduced; at that point rewrite the test or escalate the approach — do not modify business code directly.
   - If browser mode still cannot reproduce it, ask the user for error details and background; do not change business code based on static reading alone.

## Phase 2: Establish a runnable baseline

Description: confirm the prebuilt config is in place, calibrate the mock shape, then write business assertions.

1. Prepare the test environment

   Background: dependencies such as vitest / jsdom / RTL / @vitest/browser* / vitest-browser-react / playwright are prebuilt with the platform, but they are installed in the warm-up layer, not in the project's `node_modules`. So, to decide whether they are complete, use `require.resolve` (`setup_vitest.py --check` is implemented accordingly). The three config files (`vitest.config.ts`, `vitest.browser.config.ts`, `src/__tests__/setup.ts`) ship with some apps and may be missing in others.

   Workflow:
   - `cd /workspace/<app_id> && python3 .skills/debug/scripts/setup_vitest.py --check` to confirm no dependencies are missing.
   - `cd /workspace/<app_id> && python3 .skills/debug/scripts/setup_vitest.py` to scaffold the missing config files; existing configs are not overwritten, so it is safe to run.
   - Once environment and config are ready, write `repro-<bug-id>.test.tsx` under `src/__tests__/` and run it with `npx vitest run --config ...` (do not rely on `npm test`). Writing a test file does not count as modifying business code.

2. Calibrate runtime data

   ```bash
   cd /workspace/<app_id> && python3 .skills/debug/scripts/fetch_sample.py --table majors \
     --select "id,name,major_categories(name,disciplines(name))" --limit 1
   ```

   - Prefer building the mock from a real sample. The script analyzes whether nested fields are objects or arrays and generates a paste-ready mock literal. PostgREST usually returns many-to-one as an object and one-to-many as an array; the exact shape is determined by the foreign-key direction.
   - When the mock shape conflicts with `types.ts`, trust the real sample and list the type declaration as a root-cause candidate.
   - When sampling is impossible, first read the migrations and query definitions and mark the conclusion as inferred; if the shape is still uncertain, use `describe.each` to cover both object and array inputs — do not assume only one.

3. Write the failing baseline

   - Use `src/__tests__/repro-<bug-id>.test.ts` or `.tsx` for the test file.
   - One file corresponds to the core acceptance criterion of one bug.
   - Assert the user-visible result, not internal state or irrelevant implementation details.

## Phase 3: Write the minimal reproduction

Description: first make the test fail on the target behavior, then use the test as the fixed criterion for the fix.

1. node test

   ```typescript
   import { describe, it, expect } from 'vitest'
   import { targetFunction } from '../path/to/module'

   describe('Bug repro: <one-line symptom>', () => {
     it('should: <acceptance criterion>', () => {
       const result = targetFunction({ id: 1 })
       expect(result.major_categories).toBeDefined()
     })
   })
   ```

   ```bash
   npx vitest run src/__tests__/repro-<bug-id>.test.ts
   ```

2. jsdom + RTL test

   ```typescript
   import { describe, it, expect } from 'vitest'
   import { render, screen } from '@testing-library/react'
   import userEvent from '@testing-library/user-event'
   import { TargetComponent } from '../components/TargetComponent'
   describe('Bug repro: <symptom>', () => {
     it('should: <acceptance criterion>', async () => {
       const user = userEvent.setup()
       render(<TargetComponent />)
       await user.click(screen.getByRole('button', { name: 'Submit' }))
       expect(screen.getByText('Success')).toBeInTheDocument()
     })
   })
   ```

   For locating elements, prefer `getByRole`, `getByLabelText`, `getByPlaceholder`, `getByText`, and only use `getByTestId` as a last resort.

3. browser mode test

   For layout/styles/drag-and-drop/Canvas/real event bubbling; cold start ~4s. Real Chromium: layout computation, CSS, and Intersection/ResizeObserver are all available. It does not start a dev server; the component renders inside a page controlled by Vitest.

   ```typescript
   import { describe, it, expect } from 'vitest'
   import { render } from 'vitest-browser-react'
   import { page } from 'vitest/browser'
   import { TargetComponent } from '@/components/TargetComponent'
   describe('Bug repro: <symptom>', () => {
     it('should: <acceptance criterion>', async () => {
       render(<TargetComponent />)
       // ⚠️ In browser mode render() does not return { container }/getByText — locate with the page
       // locator, and assert with expect.element(...), which auto-retries (steadier than manual setTimeout).
       const el = page.getByRole('button', { name: 'Connect' })
       await expect.element(el).toBeVisible()
       expect(el.element().getBoundingClientRect().width).toBeGreaterThan(0)
       await el.click()
     })
   })
   ```

   ```bash
   npx vitest run --config vitest.browser.config.ts \
     src/__tests__/repro-<bug-id>.browser.test.tsx
   ```

   - The browser config uses a separate file and `--config`.
   - `render` does not return jsdom's container, and its return value contains no query methods; always locate with `page.*` (`page.getByRole`/`getByTestId`, etc.) + assert with `expect.element`.
   - vitest-browser-react auto-cleans up after each test, so multiple cases can each call `render`; **do not manually do `document.body.innerHTML = ""`** — it breaks the framework's internal mount state and raises `Cannot read properties of undefined`.
   - vitest 4: import `page` and `userEvent` from `vitest/browser`; `@vitest/browser/context` is deprecated.
   - For responsive issues such as 390px, fix the viewport in the config and assert that element rectangles do not overlap.
   - See Phase 5 "Visual and layout bugs" for the concrete assertion patterns for visual, layout, and stacking problems.

4. Confirm RED

   - Non-zero exit code.
   - The failure reason is the user's symptom, not an import, config, or syntax error.
   - A green test means the current approach is insufficient; do not treat green as proof the bug does not exist.

## Phase 4: Verify the fix

Description: after the fix, re-run unchanged, then add one boundary case related to the root cause.

1. Re-run unchanged

   - Do not modify the assertions to accommodate the implementation.
   - Exit code 0, zero failures, and no new errors or warnings in the output.

2. Add a boundary case

   - Pick one of: empty array, null, missing field, count of 0, no permission, or rapid repeated operation.
   - Run the boundary case together with the original reproduction.

3. Check actual execution

   ```bash
   npx vitest run --coverage src/__tests__/repro-<bug-id>.test.ts
   ```

   When coverage of the modified lines is 0, the test is not exercising the fix code; recheck the import path, conditional branches, and build cache.

## Phase 5: Vitest method quick reference

Description: choose a method by bug type. Start with the lightest approach that can assert the symptom directly, then escalate the test environment.

### Time-related bugs

Description: for debounce, throttle, setTimeout, polling, countdown, and date calculations, use fake timers to fast-forward deterministically.

```typescript
vi.useFakeTimers()
render(<Search />)                              // internal 300ms debounce
fireEvent.change(input, { target: { value: 'ab' } })
vi.advanceTimersByTime(300)                     // fast-forward to the debounce trigger (synchronous timers)
vi.advanceTimersByTimeAsync(300)                // when the timer also fires fetch/await, use the async version to drain the async chain
expect(mockSearch).toHaveBeenCalledWith('ab')
vi.useRealTimers()                              // restore when done

vi.setSystemTime(new Date('2026-01-01'))        // reproduce "depends on current time" bugs (expiry/day-rollover/timezone)
vi.runOnlyPendingTimers()                        // run only currently pending timers, avoiding infinite recursive timers
expect(vi.getTimerCount()).toBe(0)               // assert timers didn't leak (everything that should be cleared was)
```

Note: `userEvent.setup()` uses real microtasks; combining it with fake timers may cause `user.type` to hang. For components with debounce, prefer real timers and `waitFor({ timeout })`.

### Data source bugs

Description: for API, DB, or SDK problems, mock with the real shape and assert the call arguments.

```typescript
vi.mock('@/lib/queries', () => ({ searchMajors: vi.fn() }))
import { searchMajors } from '@/lib/queries'

vi.mocked(searchMajors).mockResolvedValue([/* real-shape sample, calibrate with fetch_sample first */])
vi.mocked(searchMajors).mockRejectedValue(new Error('boom'))   // reproduce the error branch
// Assert "called the API with the wrong args" — hits the root cause of many false acceptances:
expect(searchMajors).toHaveBeenCalledWith(expect.objectContaining({ categoryId: 38 }))

// Partial mock: keep the real implementation, replace only one (importActual)
vi.mock('@/lib/utils', async (orig) => ({ ...(await orig()), formatDate: vi.fn() }))

// Need an external variable in the mock factory → vi.hoisted (mock is hoisted to the top of the file, ordinary vars are not yet defined)
const { fakeData } = vi.hoisted(() => ({ fakeData: [{ id: 1 }] }))
vi.mock('@/lib/queries', () => ({ searchMajors: vi.fn(async () => fakeData) }))
```

### Network request bugs

Description: for a single request use a fetch stub; for multiple endpoints, GraphQL, or when you need to assert the request body, use MSW.

Lightweight:

```typescript
vi.stubGlobal('fetch', vi.fn(async () => ({ ok: false, status: 500, json: async () => ({}) })))
// reproduce the error-handling branch; call vi.unstubAllGlobals() when done
```

Complex scenario:

```typescript
import { setupServer } from 'msw/node'
import { http, HttpResponse } from 'msw'
const server = setupServer(
  http.get('/api/majors', () => HttpResponse.json([{ id: 1, name: 'Computer Science' }])),
  http.post('/api/order', () => new HttpResponse(null, { status: 403 })),  // reproduce the 403 branch
)
beforeAll(() => server.listen({ onUnhandledRequest: 'error' }))  // unhandled requests error out directly
afterEach(() => server.resetHandlers()); afterAll(() => server.close())
```

### Environment-variable branch bugs

Description: use environment variables to pin the prod/dev or feature-flag branch, and restore the environment after the test.

```typescript
vi.stubEnv('NODE_ENV', 'production')       // force an environment, reproduce the "only in prod" branch
vi.stubEnv('VITE_FEATURE_X', 'off')
// call vi.unstubAllEnvs() when done
```

### Async and race-condition bugs

Description: wait for fetch to settle, for the eventually-consistent state, or for an async condition — do not use fixed sleeps.

```typescript
await waitFor(() => expect(screen.getByText('Computer Science category')).toBeInTheDocument(), { timeout: 3000 })
expect(await screen.findByText('Computer Science category')).toBeInTheDocument()   // findBy waits built-in
await expect.poll(() => store.status, { timeout: 5000 }).toBe('ready')  // re-evaluate an "eventually consistent" value repeatedly
await vi.waitUntil(() => window.__ready === true, { timeout: 5000 })    // wait for a condition to be true, abort immediately on error
```

Note: `expect.poll` does not support snapshot, resolves, or toThrow.

### Type and data-shape bugs

Description: when the type declaration disagrees with the runtime truth, use schema validation and compile-time type assertions to check each of the two contract layers separately.

```typescript
// Runtime validation: does the data actually conform to the schema (closer to "the truth" than pure types; requires zod)
import { z } from 'zod'
const Major = z.object({ id: z.number(), major_categories: z.object({ name: z.string() }) })
expect(realSample).toEqual(expect.schemaMatching(Major))   // real sample fails the schema → the type declaration is the root cause

// Compile-time type assertion (requires the project to have tsc; run vitest --typecheck)
expectTypeOf(searchMajors).returns.resolves.toEqualTypeOf<Major[]>()
```

### The same bug across multiple inputs

Description: when the same acceptance criterion has multiple nested shapes, use parameterized tests to cover each input.

```typescript
describe.each([
  ['to-one object', { name: 'Computer Science category', disciplines: { name: 'Engineering' } }],
  ['to-many array', [{ name: 'Computer Science category', disciplines: [{ name: 'Engineering' }] }]],
])('nested shape=%s', (_l, shape) => {
  it('result card shows the major category', async () => { /* build mock from shape + assert */ })
})
```

### Intermittent and flaky bugs

Description: use retries and repeated runs to amplify the race, then clean up module-level state leaks.

```typescript
it('intermittent race', { retry: 3 }, async () => { /* ... */ })       // re-run on failure
it('stability', { repeats: 20 }, async () => { /* ... */ })      // run 20 times even when passing, to force out the intermittent case
// Intermittent cases caused by cross-test contamination (module-level state leaks):
afterEach(() => vi.resetModules())
```

### Visual and layout bugs

Description: browser mode is real Chromium, the layout engine has run fully, so size, position, stacking, occlusion, and overflow can all be read as numeric values and asserted directly. Always resolve visual problems with numeric and boolean criteria.

Capability boundary: `page.getBy*` returns a locator, not an element; `expect.element` has built-in polling retries. To read geometric values, use `.element()` to get the real DOM node (the official stance positions this as an escape hatch, and reading geometric values is a legitimate use). At that point you lose retries, so first use `expect.element` to wait for the element to stabilize, then read the rect.

```typescript
import { page } from 'vitest/browser'

const card = page.getByRole('article', { name: 'Major card' })
await expect.element(card).toBeVisible()      // non-empty bounding box + visibility not hidden
await expect.element(card).toBeInViewport()   // 4.0+, within the viewport (fails when the element is pushed off-screen)
const el = card.element() as HTMLElement
```

```typescript
// 1) Dimension collapse / squashed
const r = el.getBoundingClientRect()
expect(r.width).toBeGreaterThan(0)
expect(r.height).toBeGreaterThan(40)

// 2) Two elements overlap (intersecting rectangles means overlap)
const a = elA.getBoundingClientRect(), b = elB.getBoundingClientRect()
const overlap = a.left < b.right && b.left < a.right && a.top < b.bottom && b.top < a.bottom
expect(overlap).toBe(false)

// 3) Clipped by the parent container (child exceeds the parent's visible rectangle)
const p = el.parentElement!.getBoundingClientRect()
expect(r.right).toBeLessThanOrEqual(p.right + 0.5)   // allow sub-pixel tolerance
expect(r.bottom).toBeLessThanOrEqual(p.bottom + 0.5)

// 4) Content overflow (horizontal scrollbar, clipped text)
expect(el.scrollWidth).toBeLessThanOrEqual(el.clientWidth)
expect(document.documentElement.scrollWidth)
  .toBeLessThanOrEqual(document.documentElement.clientWidth)   // should not scroll horizontally at 390px

// 5) Stacking / occlusion: is the thing hit at the center point actually itself?
const hit = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2)
expect(el.contains(hit) || el === hit).toBe(true)

// 6) Computed style (opacity:0, color, z-index, overflow — things toBeVisible can't catch)
expect(getComputedStyle(el).opacity).not.toBe('0')
await expect.element(card).toHaveStyle({ position: 'fixed' })

// 7) Element count / whether the canvas actually drew something
expect(page.getByRole('listitem').elements().length).toBe(3)
const cvs = page.getByRole('img', { name: 'Terrain' }).element() as HTMLCanvasElement
const px = cvs.getContext('2d')!.getImageData(0, 0, cvs.width, cvs.height).data
expect(px.some(v => v !== 0)).toBe(true)      // all 0 = black screen / empty canvas
```

Notes:

- `toBeVisible` is based on geometry and computed style: zero-size and `display:none` are judged invisible, but **`opacity: 0` still counts as visible**; transparency-class problems must be checked with `getComputedStyle`.
- For responsive problems, fix the viewport in the browser config (e.g. 390×844); do not rely on resizing the window.
- Before asserting layout after fonts or images have loaded, first `await document.fonts.ready`.
- On a WebGL/three.js canvas, `getContext('2d')` returns null; assert scene objects instead (mesh count, camera position) or use `readPixels` — do not read pixels via the 2d context.
- Do not use `toMatchScreenshot` with baseline screenshots: it depends on consistent font rendering, GPU, browser version, and platform, is unstable across environments, and requires committing and maintaining baseline images. Use the numeric criteria above for all visual acceptance instead.

### Structural regression

Description: snapshots are for stable structure; they do not replace visual size, position, and stacking assertions.

```typescript
expect(container).toMatchSnapshot()                 // large structure, separate .snap
expect(parsed).toMatchInlineSnapshot()              // small object, snapshot written into the source
expect(el.innerHTML).toMatchFileSnapshot('./__snap__/x.html')  // rendered output
expect(() => parse(bad)).toThrowErrorMatchingInlineSnapshot()  // error-message regression
```

### Preventing false green

Description: use assertion counts, async assertions, and unreachable branches to confirm the test actually executed the target code.

```typescript
// 1) Assertion-count guard — when an async callback doesn't fire, the case goes falsely green; this line forces it to run at least N assertions
expect.hasAssertions()                    // ran at least 1 assertion
expect.assertions(2)                      // ran exactly 2 assertions

// 2) resolves/rejects must be awaited, otherwise it passes before the promise settles = always false green
await expect(searchMajors('x')).resolves.toHaveLength(2)   // ← missing await = false green
await expect(fn()).rejects.toThrow('permission')

// 3) Collect multiple failure points at once (multi-branch assertions; don't let one failure hide the rest)
expect.soft(a).toBe(1); expect.soft(b).toBe(2)

// 4) A branch that should never be reached — reaching it fails
if (unexpected) expect.unreachable('should not enter this branch')
```

### Confirm the fix code is actually executed

Description: coverage confirms the changed lines were executed, avoiding false acceptance from editing the wrong file, the condition not being entered, or caching.

Requires `@vitest/coverage-v8`; Node 24 supports it directly:

```bash
npx vitest run --coverage src/__tests__/repro-xxx.test.tsx
# Check whether the file/line/branch coverage of your changes in the report is > 0 — 0 = that line never executed, the fix didn't take effect
```

### Narrowing scope and the failure scene during debugging

Description: only during investigation, narrow scope or dump DOM/store; remove temporary markers before committing.

```typescript
it.only('run only this one', () => {})               // run only the target (note: errors when CI allowOnly is off)
it.fails('known unfixed bug', () => {})        // record a known bug (assert it currently fails)
it.skipIf(process.env.CI)('local only', () => {})
onTestFailed(() => console.log(document.body.innerHTML))  // print the DOM/store scene on failure, speeds up localization
```

### Common assertions

Description: prefer asserting user-observable results; async resolves/rejects must be awaited.

```typescript
expect(el).toBeInTheDocument()
expect(screen.getAllByText('Engineering').length).toBeGreaterThan(0)
expect(fn).toHaveBeenCalledWith(expect.objectContaining({ id: 1 }))
expect(obj).toStrictEqual({ a: 1 })            // stricter than toEqual: checks undefined keys / sparse arrays / types
expect(obj).toMatchObject({ a: 1 })            // compares a subset only
await expect(searchMajors('x')).resolves.toHaveLength(2)   // must await
await expect(fn()).rejects.toThrow('permission')
```

### Cleanup

Description: prefer config-based mock cleanup; when no config exists, restore all mutable state after each test.

`vitest.config.ts → test: { clearMocks: true, restoreMocks: true }`, otherwise `afterEach(() => { vi.clearAllMocks(); vi.useRealTimers(); vi.unstubAllGlobals(); vi.unstubAllEnvs() })`.

## Phase 6: Dependencies and general notes

### Capabilities that require installing dependencies

Description: core test dependencies such as vitest / jsdom / RTL / @vitest/browser* / vitest-browser-react / playwright are prebuilt with the base layer and need no installation. Only install the **extra** capabilities below on demand when they are used and not already prebuilt; public network is not guaranteed, so install in the background + poll to confirm.

| Capability | What to install | Fallback if install fails |
|------|--------|-------------|
| MSW network interception | `msw` | fall back to `vi.stubGlobal('fetch')` |
| Coverage | `@vitest/coverage-v8` | fall back to "add an assertion on the changed line to confirm it was reached" |
| Schema validation | `zod` (or valibot/arktype) | fall back to asserting the real sample field by field manually |
| Type testing `--typecheck` | project already has `tsc` (Vue needs `vue-tsc`) | skip for pure JS projects, use schemaMatching runtime validation |

```bash
cd /workspace/<app_id> && nohup pnpm add -D <package> > /tmp/dep.log 2>&1 &
sleep 40; tail -3 /tmp/dep.log; node -e "try{require.resolve('<package>');console.log('✅')}catch(e){console.log('⏳ sleep again')}"
```

### General notes

Description: these constraints apply to all Vitest reproductions and must not be dropped as the testing approach changes.

1. Use `src/__tests__/repro-<description>.test.ts(x)` for test files; the `repro-` prefix marks reproduction tests.
2. One test file corresponds to one core acceptance criterion of one bug.
3. Assert user-observable results, not implementation details or internal state structure.
4. Keep tests stable: mock the network, control time with fake timers, do not depend on random data.
5. The acceptance criterion must equal the phenomenon the user described itself; do not use an approximate stand-in.

### Runtime environment

Test environment: dependencies are prebuilt with the platform (vitest / jsdom / RTL / @vitest/browser* / vitest-browser-react / playwright), installed in the warm-up layer rather than the project's `node_modules`, so `ls node_modules` won't show them but they resolve normally — no `npm install` / `pnpm add` needed; browser mode uses the system `/usr/bin/chromium`, never `playwright install`. The three config files (`vitest.config.ts`, `vitest.browser.config.ts`, `src/__tests__/setup.ts`) ship with some apps and may be missing in others. Workflow:

   - `cd /workspace/<app_id> && python3 .skills/debug/scripts/setup_vitest.py --check` to confirm no dependencies are missing.
   - `cd /workspace/<app_id> && python3 .skills/debug/scripts/setup_vitest.py` to scaffold missing config; existing files are not overwritten, so it is safe to run.
   - Once ready, write `src/__tests__/repro-*.test.tsx` and run with `npx vitest run --config ...`.
