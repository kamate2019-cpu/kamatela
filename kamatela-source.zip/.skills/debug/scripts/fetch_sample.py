#!/usr/bin/env python3
"""fetch_sample.py — fetch one real data sample to calibrate mock shape.

Usage:
    # Supabase / PostgREST: reads VITE_SUPABASE_URL / VITE_SUPABASE_ANON_KEY from .env
    python3 scripts/fetch_sample.py \
        --table majors \
        --select "id,name,category_id,code,major_categories(name,disciplines(name))" \
        --limit 1

    # Any HTTP endpoint
    python3 scripts/fetch_sample.py --url "$VITE_SUPABASE_URL/rest/v1/majors?limit=1"

    # Custom .env path (default ./.env)
    python3 scripts/fetch_sample.py --env ./app/.env --table majors --select "*"

Prints the real JSON, a per-field OBJECT/ARRAY shape analysis, and a paste-ready TS mock literal.
Exit: 0 ok; 1 on fetch failure (network / auth / bad field).
"""
from __future__ import annotations

import argparse
import json
import re
import sys
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

PROBE_TIMEOUT_S = 20.0


def load_env(env_path: Path) -> dict[str, str]:
    """Parse .env (ignoring comments, blank lines, the export prefix, and quotes). Returns an empty dict if nothing is found."""
    env: dict[str, str] = {}
    if not env_path.exists():
        return env
    for raw in env_path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        line = line.removeprefix("export ").strip()
        if "=" not in line:
            continue
        key, val = line.split("=", 1)
        val = val.strip().strip('"').strip("'")
        env[key.strip()] = val
    return env


def http_get_json(url: str, headers: dict[str, str]) -> object:
    """GET a URL and parse JSON. Bypass the environment proxy (in the sandbox the proxy makes localhost time out)."""
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    req = urllib.request.Request(url, headers=headers)
    with opener.open(req, timeout=PROBE_TIMEOUT_S) as resp:
        body = resp.read().decode("utf-8", errors="replace")
    return json.loads(body)


def build_supabase_url(base: str, table: str, select: str, limit: int) -> str:
    """Build the Supabase/PostgREST REST query URL (select + limit)."""
    base = base.rstrip("/")
    query = urllib.parse.urlencode({"select": select, "limit": str(limit)})
    return f"{base}/rest/v1/{table}?{query}"


def analyze_shape(value: object, path: str = "$", lines: list[str] | None = None) -> list[str]:
    """Recursively analyze the JSON shape, focusing on flagging whether nested relational fields are OBJECT or ARRAY.

    This is the core value of the script: long JSON is easy to misread by eye; the script tells you
    explicitly how to read each nested field (.field.name vs .field[0].name).
    """
    if lines is None:
        lines = []
    if isinstance(value, list):
        lines.append(f"{path:<40} ARRAY(len={len(value)})  → read as: {path}[0]")
        if value:
            analyze_shape(value[0], f"{path}[0]", lines)
    elif isinstance(value, dict):
        for key, sub in value.items():
            child = f"{path}.{key}"
            if isinstance(sub, dict):
                lines.append(f"{child:<40} OBJECT  → many-to-one nesting, read as: {child}.<subfield>")
                analyze_shape(sub, child, lines)
            elif isinstance(sub, list):
                inner = "scalar" if not sub or not isinstance(sub[0], (dict, list)) else "object"
                lines.append(f"{child:<40} ARRAY(len={len(sub)}, element={inner})  → one-to-many nesting, read as: {child}[0]")
                if sub and isinstance(sub[0], (dict, list)):
                    analyze_shape(sub[0], f"{child}[0]", lines)
            else:
                t = type(sub).__name__ if sub is not None else "null"
                lines.append(f"{child:<40} {t}")
    return lines


def to_ts_literal(value: object, indent: int = 0) -> str:
    """Convert one real sample into a paste-ready TS object literal (for use as a mock return value)."""
    pad = "  " * indent
    pad_in = "  " * (indent + 1)
    if isinstance(value, dict):
        if not value:
            return "{}"
        items = [f"{pad_in}{k}: {to_ts_literal(v, indent + 1)}" for k, v in value.items()]
        return "{\n" + ",\n".join(items) + f"\n{pad}}}"
    if isinstance(value, list):
        if not value:
            return "[]"
        items = [f"{pad_in}{to_ts_literal(v, indent + 1)}" for v in value]
        return "[\n" + ",\n".join(items) + f"\n{pad}]"
    if isinstance(value, str):
        return json.dumps(value, ensure_ascii=False)
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "true" if value else "false"
    return str(value)


def main() -> int:
    """Parse command-line args, fetch one real data sample, and output shape analysis and the mock literal."""
    parser = argparse.ArgumentParser(
        description="Fetch one real data sample to calibrate the mock shape (REPRODUCE phase)",
    )
    parser.add_argument("--url", help="any HTTP endpoint URL (GET). If given, supabase args are ignored.")
    parser.add_argument("--table", help="Supabase table name, e.g. majors")
    parser.add_argument("--select", default="*", help="PostgREST select expression, including nested relations")
    parser.add_argument("--limit", type=int, default=1, help="how many rows to fetch, default 1")
    parser.add_argument("--env", default="./.env", help=".env path, default ./.env")
    parser.add_argument("--header", action="append", default=[], help="extra header, e.g. 'Authorization: Bearer xxx', repeatable")
    args = parser.parse_args()

    headers: dict[str, str] = {}
    for h in args.header:
        if ":" in h:
            k, v = h.split(":", 1)
            headers[k.strip()] = v.strip()

    if args.url:
        url = args.url
    else:
        if not args.table:
            print("ERROR: need one of --url or --table", file=sys.stderr)
            return 1
        env = load_env(Path(args.env))
        base = env.get("VITE_SUPABASE_URL") or env.get("SUPABASE_URL")
        key = env.get("VITE_SUPABASE_ANON_KEY") or env.get("SUPABASE_ANON_KEY")
        if not base or not key:
            print(f"ERROR: could not find VITE_SUPABASE_URL / VITE_SUPABASE_ANON_KEY in {args.env}", file=sys.stderr)
            return 1
        url = build_supabase_url(base, args.table, args.select, args.limit)
        headers.setdefault("apikey", key)
        headers.setdefault("Authorization", f"Bearer {key}")

    try:
        data = http_get_json(url, headers)
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")[:500]
        print(f"ERROR: HTTP {exc.code} — {detail}", file=sys.stderr)
        return 1
    except Exception as exc:
        print(f"ERROR: fetch failed — {exc}", file=sys.stderr)
        return 1

    sample = data[0] if isinstance(data, list) and data else data

    print("=" * 60)
    print("① Real response (one sample)")
    print("=" * 60)
    print(json.dumps(sample, ensure_ascii=False, indent=2))

    print()
    print("=" * 60)
    print("② Shape analysis (is the nested field an object or an array? Decides the mock and how to read it)")
    print("=" * 60)
    for line in analyze_shape(sample):
        print("  " + line)

    print()
    print("=" * 60)
    print("③ Suggested mock literal (use it as searchXxx()'s mockResolvedValue)")
    print("=" * 60)
    print("// ⚠️ This is the real runtime shape — if it conflicts with the types.ts declaration, types.ts is the root-cause candidate")
    print(to_ts_literal(sample))

    return 0


if __name__ == "__main__":
    sys.exit(main())
