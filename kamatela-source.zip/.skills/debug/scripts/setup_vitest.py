#!/usr/bin/env python3
"""setup_vitest.py — check test deps and scaffold vitest config files.

Usage:
    python3 scripts/setup_vitest.py --check   # check deps are resolvable (read-only)
    python3 scripts/setup_vitest.py           # write missing config files (existing ones are skipped)
    python3 scripts/setup_vitest.py --dir ./app

Writes vitest.config.ts / vitest.browser.config.ts / src/__tests__/setup.ts when absent.
Exit: 0 ok; 1 when --check finds missing deps.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

VITEST_CONFIG = '''import { defineConfig } from "vitest/config";
import react from "@vitejs/plugin-react";
import { createRequire } from "node:module";
import path from "node:path";

const require = createRequire(import.meta.url);

const reactDir = path.dirname(
  require.resolve("react/package.json", { paths: [require.resolve("@testing-library/react")] })
);
const reactDomDir = path.dirname(
  require.resolve("react-dom/package.json", { paths: [require.resolve("@testing-library/react")] })
);

export default defineConfig({
  plugins: [react()],
  test: {
    environment: "jsdom",
    globals: true,
    setupFiles: ["./src/__tests__/setup.ts"],
    env: { NODE_ENV: "test" },
    exclude: ["**/node_modules/**", "**/*.browser.test.*"],
  },
  resolve: {
    dedupe: ["react", "react-dom"],
    alias: [
      { find: /^react$/, replacement: path.join(reactDir, "index.js") },
      { find: /^react\\/(.*)$/, replacement: path.join(reactDir, "$1") },
      { find: /^react-dom$/, replacement: path.join(reactDomDir, "index.js") },
      { find: /^react-dom\\/(.*)$/, replacement: path.join(reactDomDir, "$1") },
      { find: "@", replacement: path.resolve(import.meta.dirname, "./src") },
    ],
  },
});
'''

BROWSER_CONFIG = '''import { defineConfig } from "vitest/config";
import react from "@vitejs/plugin-react";
import { playwright } from "@vitest/browser-playwright";
import { createRequire } from "node:module";
import path from "node:path";

if (process.env.NODE_ENV === "production" || !process.env.NODE_ENV) {
  process.env.NODE_ENV = "test";
}

const require = createRequire(import.meta.url);

const reactDir = path.dirname(
  require.resolve("react/package.json", { paths: [require.resolve("@testing-library/react")] })
);
const reactDomDir = path.dirname(
  require.resolve("react-dom/package.json", { paths: [require.resolve("@testing-library/react")] })
);

export default defineConfig({
  plugins: [react()],
  test: {
    env: { NODE_ENV: "test" },
    include: ["**/*.browser.test.*"],
    setupFiles: ["./src/__tests__/setup.browser.ts"],
    browser: {
      enabled: true,
      screenshotFailures: false,
      provider: playwright({
        launchOptions: {
          executablePath: "/usr/bin/chromium",
          args: ["--no-sandbox", "--disable-dev-shm-usage"],
        },
      }),
      headless: true,
      instances: [{ browser: "chromium" }],
    },
  },
  resolve: {
    dedupe: ["react", "react-dom"],
    alias: [
      { find: /^react$/, replacement: path.join(reactDir, "index.js") },
      { find: /^react\\/(.*)$/, replacement: path.join(reactDir, "$1") },
      { find: /^react-dom$/, replacement: path.join(reactDomDir, "index.js") },
      { find: /^react-dom\\/(.*)$/, replacement: path.join(reactDomDir, "$1") },
      { find: "@", replacement: path.resolve(import.meta.dirname, "./src") },
    ],
  },
});
'''

SETUP_TS = 'import "@testing-library/jest-dom/vitest";\n'

SETUP_BROWSER_TS = (
    'export {};\n'
    '\n'
    'try {\n'
    '  await import("@/index.css");\n'
    '} catch {}\n'
)

FILES = [
    ("vitest.config.ts", VITEST_CONFIG),
    ("vitest.browser.config.ts", BROWSER_CONFIG),
    ("src/__tests__/setup.ts", SETUP_TS),
    ("src/__tests__/setup.browser.ts", SETUP_BROWSER_TS),
]

DEPS = [
    "vitest", "jsdom",
    "@testing-library/react", "@testing-library/jest-dom", "@testing-library/user-event",
    "@vitest/browser", "@vitest/browser-playwright", "vitest-browser-react", "playwright",
]
DEP_VERSIONS = {
    "vitest": "4.1.10",
    "jsdom": "29.1.1",
    "@testing-library/react": "16.3.2",
    "@testing-library/jest-dom": "6.10.0",
    "@testing-library/user-event": "14.6.4",
    "@vitest/browser": "4.1.10",
    "@vitest/browser-playwright": "4.1.10",
    "vitest-browser-react": "2.2.0",
    "playwright": "1.62.1",
}


def check_deps(root: Path) -> list[str]:
    """Probe all dependencies at once via node's real module resolution, returning the missing list (not ls node_modules).

    Dependencies are prebuilt in a pnpm layout, with packages under /data/shadcn/node_modules (not on the app directory's parent chain).
    The node runtime can resolve them (NODE_PATH / pnpm symlinks), so use require.resolve rather than a filesystem check.
    """
    script = """
const deps = JSON.parse(process.argv[1]);
const missing = deps.filter((d) => {
  try { require.resolve(d); return false; } catch { return true; }
});
console.log(JSON.stringify(missing));
"""
    r = subprocess.run(
        ["node", "-e", script, json.dumps(DEPS)],
        cwd=str(root), capture_output=True, text=True,
    )
    if r.returncode != 0:
        print(r.stderr.strip(), file=sys.stderr)
        return list(DEPS)
    return json.loads(r.stdout.strip() or "[]")


def install_cmd(missing: list[str]) -> str:
    """Environment fallback: generate a one-shot background install command, installing only the missing packages, with exact versions, skipping the playwright browser download."""
    spec = " ".join(f"{d}@{DEP_VERSIONS[d]}" for d in missing)
    return (
        f"PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD=1 nohup pnpm add -D {spec} "
        f"> /tmp/vitest_dep_install.log 2>&1 & "
        f"echo \"installing, pid $!, log=/tmp/vitest_dep_install.log\"; "
        f"sleep 60; tail -5 /tmp/vitest_dep_install.log"
    )


def cmd_check(root: Path) -> int:
    """Probe in one command whether all dependencies are resolvable."""
    missing = check_deps(root)
    for d in DEPS:
        print(f"  {'✅' if d not in missing else '❌'}  {d}")
    print()
    if missing:
        print("This template is non-shadcn with a non-web app_type; its warm-up layer does not prebuild the test deps, so they need installing.")
        print("One-shot background install (internal registry, skips the playwright browser download), then scaffold config:")
        print()
        print(f"  cd {root} && {install_cmd(missing)}")
        print()
        print("If the log doesn't show completion after install, repeat the sleep+tail line above and wait another round; once ready, run setup_vitest.py to scaffold config.")
        return 1
    print("✅ Dependencies complete.")
    return 0


def cmd_setup(root: Path) -> int:
    """Scaffold the missing config files (skip existing ones, do not overwrite)."""
    created, skipped = [], []
    for rel, content in FILES:
        path = root / rel
        if path.exists():
            skipped.append(rel)
            continue
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        created.append(rel)
    if created:
        print("Scaffolded:")
        for f in created:
            print(f"  + {f}")
    if skipped:
        print("Already present (skipped):")
        for f in skipped:
            print(f"  = {f}")
    print()
    print("Config ready. Write src/__tests__/repro-<bug>.test.tsx directly and run with npx vitest run --config ...")
    return 0


def main() -> int:
    """Parse command-line args and run the dependency check or config scaffolding."""
    parser = argparse.ArgumentParser(description="Scaffold vitest config for legacy apps (deps are prebuilt by the platform by default)")
    parser.add_argument("--check", action="store_true", help="probe whether dependencies are complete")
    parser.add_argument("--dir", default=".", help="project root, defaults to current directory")
    args = parser.parse_args()

    root = Path(args.dir).resolve()
    if not (root / "package.json").exists():
        print(f"ERROR: no package.json under {root}", file=sys.stderr)
        return 1

    return cmd_check(root) if args.check else cmd_setup(root)


if __name__ == "__main__":
    sys.exit(main())
